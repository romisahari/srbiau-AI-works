#include <bits/stdc++.h>
using namespace std;

#define pub push_back
#define pii pair<int, int>
#define S second
#define F first

const int maxn = 1e5;
int best = -1;
vector <int> adj[maxn];

void print_steps(map <pii, pii> father, pii goal){

    cout <<"the cites for A and B in each step is:" <<endl;

    int a = goal.F, b = goal.S;
    while(a != b){
        cout <<a <<' ' <<b <<endl;
        pii x = father[make_pair(a, b)];
        a = x.F;
        b = x.S;
    }
    cout <<a <<' ' << b <<endl;

    return;
}

int UCS(bool out, int n, vector <int> *adj, vector <int> *weight, pii start, pii goal){

    set <pair<int, pii > > ucs;
    map <pii, int> w_now;
    map <pii, pii> father;
    pair <int, pii > bestNow = make_pair(0, start);
    ucs.clear();
    w_now.clear();
    ucs.insert(bestNow);

    while((int)ucs.size()){
        bestNow = *ucs.begin();
        ucs.erase(bestNow);
        //check if done
        if(bestNow.S.F == goal.F and bestNow.S.S == goal.S){
            if(out){
                print_steps(father, goal);

            }
            return w_now[bestNow.S];
        }
        //find the children
        int l = bestNow.S.F, r = bestNow.S.S;
        for(int i = 0; i < (int)adj[l].size(); i++){
            for(int j = 0; j < (int)adj[r].size(); j++){
                //making the child
                pii v = make_pair(adj[l][i], adj[r][j]);
                int w = bestNow.F + max(weight[l][i], weight[r][j]);
                //check if the child would be update
                if(w_now.find(v) == w_now.end() or w_now[v] > w){
                    //updating the child
                    w_now[v] = w;
                    father[v] = bestNow.S;
                    ucs.erase(make_pair(w, v));
                    ucs.insert(make_pair(w_now[v], v));
                }
            }
        }
    }
    return -1;
}

void answer(int n, vector <int> *adj, vector <int> *weight, pii goal){

    int best = -1;
    pii ans = make_pair(-1, -1);
    //fixing the start node in UCS(the last step meeting)
    for(int i = 0; i < n; i ++){
        pii start = make_pair(i, i);
        int x = UCS(0, n, adj, weight, start, goal);
        if(best == -1 || best > x){
            best = x;
            ans = start;
        }
    }
    cout <<"the best cost is: " <<best <<endl;
    UCS(1, n, adj, weight, ans, goal);
    return;
}

int main()
{
    int n, a, b, m;
    cout <<"give me the num of : city, roads, A's city, B's city :" <<endl;
    cin >>n >>m >>a >>b;
    pii goal = make_pair(a, b);
    vector <int> adj[n + 1], weight[n + 1];
    cout <<"give me the ends of each road and the time it takes:" <<endl;
    for(int i = 0; i < m; i ++){
        int u, v, w;
        cin >>u >>v >>w;
        adj[u].pub(v);
        adj[v].pub(u);
        weight[u].pub(w);
        weight[v].pub(w);
    }
    for(int i = 0; i < n; i ++){
        adj[i].pub(i);
        weight[i].pub(0);
    }
    answer(n, adj, weight, goal);
    return 0;
}
